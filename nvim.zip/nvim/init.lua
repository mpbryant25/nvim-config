require("matt")
vim.opt.relativenumber = true
vim.opt.number = true
